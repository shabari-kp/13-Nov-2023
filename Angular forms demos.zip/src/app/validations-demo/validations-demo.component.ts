import { Component } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-validations-demo',
  templateUrl: './validations-demo.component.html',
  styleUrls: ['./validations-demo.component.css']
})
export class ValidationsDemoComponent {
  validateForm:any;
 

  ngOnInit(): void {
  }


  constructor(private form: FormBuilder) 
  {
  
   
  
 
  this.validateForm = new FormGroup({
      'name': new FormControl(),
      'email': new FormControl(),
      'age': new FormControl(),
      'address': new FormGroup({
        'country': new FormControl(),
        'city': new FormControl()
      })
    });
    
  }
 

  register(validateForm: any) {
    console.log('Registration successful.');
    console.log(validateForm.value);
    alert("Hi "+validateForm.value.name+" you information are valid.")
  }

  getControls() 
  {
    return (this.validateForm.get('address') as FormArray).controls;
     
  }
}
