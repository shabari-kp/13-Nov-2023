import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ValidationsDemoComponent } from './validations-demo.component';

describe('ValidationsDemoComponent', () => {
  let component: ValidationsDemoComponent;
  let fixture: ComponentFixture<ValidationsDemoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ValidationsDemoComponent]
    });
    fixture = TestBed.createComponent(ValidationsDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
