import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormsDemos2Component } from './forms-demos2.component';

describe('FormsDemos2Component', () => {
  let component: FormsDemos2Component;
  let fixture: ComponentFixture<FormsDemos2Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FormsDemos2Component]
    });
    fixture = TestBed.createComponent(FormsDemos2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
