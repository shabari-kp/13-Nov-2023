import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsDemos1Component } from './forms-demos1/forms-demos1.component';
import { FormsDemos2Component } from './forms-demos2/forms-demos2.component';
import { FormsDemos3Component } from './forms-demos3/forms-demos3.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { FormsDemos4Component } from './forms-demos4/forms-demos4.component';
import { TemplateFormsComplexComponent } from './template-forms-complex/template-forms-complex.component';
import { ErrorsComponent } from './Errors.component';
import { AgeValidatorDirective } from './age.validator';
import { EmailValidatorDirective } from './email.validator';
import { ValidationsDemoComponent } from './validations-demo/validations-demo.component';

@NgModule({
  declarations: [
    AppComponent,
    FormsDemos1Component,
    FormsDemos2Component,
    FormsDemos3Component,
    FormsDemos4Component,
    TemplateFormsComplexComponent,
    ErrorsComponent,
    AgeValidatorDirective,
    EmailValidatorDirective,
    ValidationsDemoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
