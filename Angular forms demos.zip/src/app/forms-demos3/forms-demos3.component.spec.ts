import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormsDemos3Component } from './forms-demos3.component';

describe('FormsDemos3Component', () => {
  let component: FormsDemos3Component;
  let fixture: ComponentFixture<FormsDemos3Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FormsDemos3Component]
    });
    fixture = TestBed.createComponent(FormsDemos3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
