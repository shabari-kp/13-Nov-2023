import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms'

@Component({
  selector: 'app-forms-demos3',
  templateUrl: './forms-demos3.component.html',
  styleUrls: ['./forms-demos3.component.css']
})
export class FormsDemos3Component {

  onSubmit() {
    console.log(this.contactForm.value);
  }
  
   // many obj are created 
   // this have to avoided
  contactForm = new FormGroup({
    firstname: new FormControl(),
    lastname: new FormControl(),
    email: new FormControl(),
    gender: new FormControl(),
    isMarried: new FormControl(),
    address:new FormGroup({
      city: new FormControl(),
      street: new FormControl(),
      pincode:new FormControl(),
      country: new FormControl(),
    })
  })
   

  
}
