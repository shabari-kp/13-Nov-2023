import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormsDemos4Component } from './forms-demos4.component';

describe('FormsDemos4Component', () => {
  let component: FormsDemos4Component;
  let fixture: ComponentFixture<FormsDemos4Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FormsDemos4Component]
    });
    fixture = TestBed.createComponent(FormsDemos4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
