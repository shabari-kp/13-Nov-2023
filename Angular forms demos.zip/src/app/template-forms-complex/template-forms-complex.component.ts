import { Component, OnInit } from '@angular/core';

import { User } from '../User';
import {NgForm} from "@angular/forms";

@Component({
  selector: 'app-template-forms-complex',
  templateUrl: './template-forms-complex.component.html',
  styleUrls: ['./template-forms-complex.component.css']
})
export class TemplateFormsComplexComponent implements OnInit{
  user!: User;
  
  ngOnInit(): void 
  {
    this.user=new User();
  }
  
  formSubmit(x:NgForm)
  {
    console.log(x.value);

  }
}