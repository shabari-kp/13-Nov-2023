import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateFormsComplexComponent } from './template-forms-complex.component';

describe('TemplateFormsComplexComponent', () => {
  let component: TemplateFormsComplexComponent;
  let fixture: ComponentFixture<TemplateFormsComplexComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TemplateFormsComplexComponent]
    });
    fixture = TestBed.createComponent(TemplateFormsComplexComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
