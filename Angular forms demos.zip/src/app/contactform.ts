export class contact {
    firstname!:string;
    lastname!:string;
    email!:string;
    gender!:string;
    isMarried!:boolean;
    country!:string;
    address!: {
      city:string;
      street:string;
      pincode:string;
    }
  } 