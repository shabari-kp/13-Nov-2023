import { Component } from '@angular/core';
import { country } from '../country';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-forms-demos1',
  templateUrl: './forms-demos1.component.html',
  styleUrls: ['./forms-demos1.component.css']
})
export class FormsDemos1Component {
  countryList:country[] = [
    new country("1", "India"),
    new country('2', 'USA'),
    new country('3', 'England'),
    new country('4', 'Cannada'),
    new country('5', 'Japan'),
    new country('6', 'Germany'),
    new country('7', 'France')
  ];

  onSubmit(contactForm:NgForm) {
    console.log(contactForm.value); //get all the form controls values
  }
}

