import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormsDemos1Component } from './forms-demos1.component';

describe('FormsDemos1Component', () => {
  let component: FormsDemos1Component;
  let fixture: ComponentFixture<FormsDemos1Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FormsDemos1Component]
    });
    fixture = TestBed.createComponent(FormsDemos1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
